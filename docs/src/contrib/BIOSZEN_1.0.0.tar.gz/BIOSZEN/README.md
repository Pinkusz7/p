# BIOSZEN Package

[![Build binary](https://github.com/user/repo/actions/workflows/build-binary.yaml/badge.svg)](https://github.com/user/repo/actions/workflows/build-binary.yaml)
[![R tests](https://github.com/user/repo/actions/workflows/r-tests.yml/badge.svg)](https://github.com/user/repo/actions/workflows/r-tests.yml)


BIOSZEN is a modular Shiny application for biochemical data analysis. The main
script lives in `inst/app/app.R` and is mirrored at the repository root as
`app.R`. Both files contain the same code and return the shiny object so
`runApp()` works whether the app is executed locally or from the installed
package. Install the package and launch the app with:

```R
BIOSZEN::run_app()
```

If the package is not installed, follow these steps to install it from a
local tarball and then launch the application:

1. Descarga o genera el archivo `BIOSZEN_*.tar.gz`.
2. Abre R o RStudio y ejecuta:

   ```R
   install.packages("ruta/al/BIOSZEN_1.0.0.tar.gz",
                    repos = NULL, type = "source")
   library(BIOSZEN)
   BIOSZEN::run_app()
   ```

User guides in English and Spanish are located in `inst/app/www`. They explain
how to use each button and workflow step.

## Structure
- All modules live inside `inst/app` and are sourced at runtime.
- `R/run_app.R` exposes the `run_app()` function.
- Tests under `tests/` ensure all R scripts parse correctly. Este flujo de
  trabajo también construye el paquete y publica el artefacto `.tar.gz`.

You can add more modules by placing R scripts in `inst/app/{params,stats,graficos}`.
They will be sourced automatically when the app launches.


## Downloading the package
The GitHub Actions workflows build `BIOSZEN_*.tar.gz` and upload it as an artifact
called **miapp-tarball**. After a workflow run completes, visit the *Actions*
tab, open the corresponding run and download the artifact. The downloaded ZIP
contains the package tarball. Si prefieres generar el paquete localmente, basta
con ejecutar:

```bash
R CMD build .
```

Esto producirá el archivo `BIOSZEN_*.tar.gz` en tu directorio de trabajo.

## Instalación local desde un tarball

Una vez tengas el archivo `BIOSZEN_*.tar.gz`, sigue estos pasos:

1. Abre R o RStudio en la carpeta donde guardaste el tarball.
2. Ejecuta:

   ```R
   install.packages("BIOSZEN_1.0.0.tar.gz", repos = NULL, type = "source")
   library(BIOSZEN)
   BIOSZEN::run_app()
   ```

Esto instalará el paquete y abrirá la aplicación.
