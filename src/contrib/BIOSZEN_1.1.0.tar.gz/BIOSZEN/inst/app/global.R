# app.R - Shiny interactivo con carga dinámica de archivos, gráfico por cepa o combinado,  
# descarga de PNG y Excel (.xlsx)  

library(shiny)  
library(plotly)  
library(ggplot2)  
library(readxl)  
library(dplyr)  
library(tidyr)  
library(scales)  
library(openxlsx)  
library(zip)  
library(rstatix)  
library(DT)  
library(shinyBS)  
library(nortest)  
library(DescTools)    # para DunnettTest()  
library(multcomp)     # alternativa Dunnett y glht()  
library(PMCMRplus)    # Scheffé, Conover, Nemenyi, DSCF  
library(dunn.test)    # otra implementación de Dunn  
library(broom)  
library(stringr)  
library(forcats)  
library(tibble)  
library(RColorBrewer)  
library(viridis)
library(htmlwidgets)   # para saveWidget()
library(webshot2)      # PNG desde html/plotly   (trae Chrome headless)
library(webshot)
library(ggrepel)        # etiquetas que no se sobre-ponen
library(shinyjs)
library(bslib)
library(gcplyr)
library(rlang)
library(patchwork)
library(officer)
library(rvg)

# Reporta errores indicando el archivo de origen
options(shiny.error = function(e) {
  calls <- sys.calls()
  src <- NULL
  for (i in rev(seq_along(calls))) {
    sr <- attr(calls[[i]], 'srcref')
    if (!is.null(sr)) {
      src <- basename(sr$srcfile$filename)
      break
    }
  }
  if (is.null(src)) src <- 'fuente_desconocida'
  shiny::showNotification(
    paste('Error en', src, ':', conditionMessage(e)),
    type = 'error', duration = NULL
  )
})

## Fuente y color por defecto para TODO ggplot2
theme_update(
  text = element_text(colour = "black", family = "Helvetica")
)

#──────── helpers genéricos para objetos sin método broom::tidy() ────────
# Las funciones matrix_to_tibble() y pmcmr_to_tibble() ahora residen en
# helpers.R para evitar duplicaciones.

#──────────────────────────────────────────────────────────────────────────  
# Helpers estadísticos ─ NUEVOS  
split_comparison <- function(x) {  
  stringr::str_split_fixed(x, "-", 2)  
}  

dunnett_to_tibble <- function(obj) {  
  # obj es la lista que devuelve DescTools::DunnettTest()  
  mat <- obj[[1]][ , 4, drop = FALSE]        # 4ª columna = p ajustado  
  cmp <- split_comparison(rownames(mat))  
  tibble(  
    grupo1 = cmp[, 1],  
    grupo2 = cmp[, 2],  
    p.adj  = mat[, 1]  
  )  
}  

set_control <- function(df, control_lbl) {  
  if (!is.null(control_lbl) && control_lbl %in% df$Label)  
    df$Label <- forcats::fct_relevel(df$Label, control_lbl)  
  df  
}  

# Si ya existían matrix_to_tibble() y pmcmr_to_tibble() NO los dupliques.  
#──────────────────────────────────────────────────────────────────────────  
safe_pairwise_t <- function(df, method = "sidak") {  
  res <- rstatix::pairwise_t_test(df, Valor ~ Label, p.adjust.method = method)  
  if (nrow(res) == 0) tibble() else res  
}  


# ── Nombre seguro para archivos (mantiene la extensión) ────────────  
safe_file <- function(x) {  
  # separa nombre y extensión  
  ext  <- tools::file_ext(x)           # "png"  
  name <- tools::file_path_sans_ext(x) # "NAD+_Boxplot"  
  
  # sanea solo el nombre (letras, números, _ y -)  
  name <- gsub("[^A-Za-z0-9_\\-]", "_", name)  
  
  paste0(name, ".", ext)               # vuelve a unir con .  
}  

# ── Nombre seguro para hojas de Excel ──────────────────────────────  
safe_sheet <- function(x) {  
  ## solo letras, números o "_" (lo demás → "_")  
  gsub("[^A-Za-z0-9_]", "_", x)  
}  
# ── Nombre seguro para etiquetas simples ────────────────────  
sanitize <- function(x) {  
  gsub("[/\\\\:*?\"<>|]", "_", x)  
}  

theme_light <- bs_theme(version = 5)
theme_dark  <- bs_theme(version = 5, bootswatch = "cyborg")

tab_compos <- tabPanel(
  "Panel de Composición",
  sidebarLayout(
    sidebarPanel(style="overflow-y:auto;max-height:95vh;position:sticky;top:0;",
      uiOutput("plotPicker"),
      checkboxInput("show_legend_combo", "Mostrar leyenda", value = FALSE),
      hr(),
      numericInput("nrow_combo", "Filas", 1, min = 1, max = 4),
      numericInput("ncol_combo", "Columnas", 1, min = 1, max = 4),
      numericInput("combo_width",  "Ancho px", 1920, min = 400),
      numericInput("combo_height", "Alto  px", 1080, min = 400),
      numericInput("base_size_combo", "Tamaño base (pts)", 18, min = 8),
      numericInput("fs_title_all",      "Tamaño título (pts)",     20, min = 6),
      numericInput("fs_axis_title_all", "Títulos de ejes",         16, min = 6),
      numericInput("fs_axis_text_all",  "Ticks de ejes",           14, min = 6),
      numericInput("fs_legend_all",     "Texto de leyenda",        16, min = 6),
      selectInput("combo_pal", "Paleta de color:",
                  choices = c('Original', 'Default', 'Blanco y Negro', 'Viridis',
                              'Plasma', 'Magma', 'Cividis', 'Set1', 'Set2',
                              'Set3', 'Dark2', 'Accent', 'Paired', 'Pastel1',
                              'Pastel2'),
                  selected = 'Original'),

  uiOutput("plotOverrideUI"),
      actionButton("makeCombo", "Actualiza / Previsualiza",
                   class = "btn btn-primary"),
      br(), br(),
      downloadButton("dl_combo_png",  "Descargar PNG"),
      downloadButton("dl_combo_pptx", "Descargar PPTX"),
      downloadButton("dl_combo_pdf",  "Descargar PDF")
    ),
    mainPanel(
      plotOutput("comboPreview", height = "auto")
    )
  )
)




# ──────────────────────────────────────────────────────────────────────────────  
# Helper robusto: lee una hoja Excel aunque el nombre temporal NO tenga extensión  
read_excel_tmp <- function(path, sheet = NULL) {  
  sig <- readBin(path, "raw", n = 8)  
  
  # 0xD0CF11E0 = formato OLE (xls 97-2003)  
  is_xls  <- identical(sig[1:4], as.raw(c(0xD0,0xCF,0x11,0xE0)))  
  # 0x504B0304 = inicio de archivo ZIP (xlsx, xlsm, ods…)  
  is_zip  <- identical(sig[1:4], as.raw(c(0x50,0x4B,0x03,0x04)))  
  
  if (is_xls)       return(readxl::read_xls (path, sheet = sheet))  
  if (is_zip)       return(readxl::read_xlsx(path, sheet = sheet))  
  
  stop("El archivo subido no es un Excel válido (.xls o .xlsx)")  
}  
# ──────────────────────────────────────────────────────────────────────────────  

# ── Función para generar el Excel de resumen por parámetro ────────────  
generate_summary_wb <- function(datos, params) {  
  wb <- createWorkbook()  
  for (param in params) {  
    sheet <- safe_sheet(param)  
    addWorksheet(wb, sheet)  
    
    # 1) Detalle técnico  
    det <- datos %>%  
      dplyr::filter(!is.na(Strain), !is.na(Media)) %>%  
      dplyr::select(  
        Strain, Media, Orden,  
        BiologicalReplicate, TechnicalReplicate,  
        Valor = !!rlang::sym(param)  
      ) %>%  
      dplyr::arrange(Strain, BiologicalReplicate, TechnicalReplicate)  
    
    # 2) Orden de medios según 'Orden'  
    medias_order <- det %>%  
      dplyr::distinct(Media, Orden) %>%  
      dplyr::arrange(Orden) %>%  
      dplyr::pull(Media)  
    
    # 3) Escribir por cepa  
    fila <- 1  
    for (s in unique(det$Strain)) {  
      writeData(wb, sheet, paste("Strain:", s),  
                startRow = fila, startCol = 1)  
      fila <- fila + 1  
      
      tab_cepa <- det %>%  
        dplyr::filter(Strain == s) %>%  
        dplyr::select(BiologicalReplicate, TechnicalReplicate, Media, Valor) %>%  
        tidyr::pivot_wider(  
          id_cols    = c(BiologicalReplicate, TechnicalReplicate),  
          names_from = Media,  
          values_from = Valor,  
          values_fill = NA  
        ) %>%  
        dplyr::select(BiologicalReplicate, dplyr::all_of(medias_order)) %>%  
        dplyr::rename(RepBiol = BiologicalReplicate)  
      
      writeData(wb, sheet, tab_cepa,  
                startRow    = fila,  
                startCol    = 1,  
                headerStyle = createStyle(textDecoration = "bold"))  
      fila <- fila + nrow(tab_cepa) + 2  
    }  
    
    # 4) Resumen por réplica biológica  
    writeData(wb, sheet, "Resumen por réplica biológica",  
              startRow    = fila,  
              startCol    = 1,  
              headerStyle = createStyle(fontSize = 12, textDecoration = "bold"))  
    fila <- fila + 1  
    
    resumen <- det %>%  
      dplyr::group_by(Strain, BiologicalReplicate, Media) %>%  
      dplyr::summarise(Promedio = mean(Valor, na.rm = TRUE), .groups = "drop") %>%  
      tidyr::pivot_wider(  
        id_cols    = c(Strain, BiologicalReplicate),  
        names_from = Media,  
        values_from = Promedio,  
        values_fill = NA  
      ) %>%  
      dplyr::arrange(Strain, BiologicalReplicate) %>%  
      dplyr::rename(RepBiol = BiologicalReplicate)  
    
    writeData(wb, sheet, resumen,  
              startRow    = fila,  
              startCol    = 1,  
              headerStyle = createStyle(textDecoration = "bold"))  
  }  
  wb  
}  

# ────────────────────────────────────────────────────────────────
# Funciones Growth Rates – robustas y permisivas
# (colócalas en el ámbito global, antes de server)
# ────────────────────────────────────────────────────────────────

# 1. Fase exponencial - ROBUSTA
identify_exponential_phase_robust <- function(df, time_col, measure_col,
                                              umax_lower_bound = 0.05,
                                              umax_upper_bound = 0.25,
                                              max_iterations = 10,
                                              initial_r_squared_threshold = 0.95) {
  
  best_model <- NULL
  best_r2    <- -Inf
  best_start <- best_end <- NULL
  
  # limpia NAs y filtrado del 5-95 %
  df <- df[!is.na(df[[time_col]]) & !is.na(df[[measure_col]]), ]
  df <- dplyr::filter(df,
                      dplyr::between(df[[measure_col]],
                                     stats::quantile(df[[measure_col]], 0.05),
                                     stats::quantile(df[[measure_col]], 0.95)))
  
  min_pts            <- 10
  r2_threshold       <- initial_r_squared_threshold
  
  for (i in seq_len(max_iterations)) {
    for (start in seq_len(nrow(df) - min_pts)) {
      for (end in seq(start + min_pts, nrow(df))) {
        
        if ((end - start + 1) < min_pts) next
        
        model <- tryCatch(
          lm(log(df[[measure_col]][start:end]) ~
               df[[time_col]][start:end]),
          error = function(e) NULL)
        
        if (is.null(model)) next
        
        r2   <- summary(model)$r.squared
        umax <- coef(model)[2]
        
        if (!is.na(r2) &&
            umax > umax_lower_bound &&
            umax < umax_upper_bound &&
            r2   > r2_threshold &&
            r2   > best_r2) {
          
          best_r2    <- r2
          best_model <- model
          best_start <- start
          best_end   <- end
        }
      }
    }
    
    # heurística de ajuste de límites
    if (!is.null(best_model)) {
      umax <- coef(best_model)[2]
      if (umax < umax_lower_bound) {
        min_pts          <- max(min_pts - 1, 5)
        umax_lower_bound <- umax_lower_bound - 0.01
        r2_threshold     <- max(r2_threshold - 0.01, 0.90)
      } else if (umax > umax_upper_bound) {
        min_pts          <- min(min_pts + 1, nrow(df) - 5)
        umax_upper_bound <- umax_upper_bound + 0.01
        r2_threshold     <- min(r2_threshold + 0.01, 0.99)
      } else {
        break
      }
    }
  }
  
  list(start = best_start, end = best_end, model = best_model)
}

# 2. Fase exponencial - PERMISIVA
identify_exponential_phase_permissive <- function(df, time_col, measure_col,
                                                  umax_lower_bound = 0.01,
                                                  umax_upper_bound = 0.50,
                                                  max_iterations   = 10) {
  
  best_model <- NULL
  best_r2    <- -Inf
  best_start <- best_end <- NULL
  
  df <- df[!is.na(df[[time_col]]) & !is.na(df[[measure_col]]), ]
  df <- dplyr::filter(df,
                      dplyr::between(df[[measure_col]],
                                     stats::quantile(df[[measure_col]], 0.05),
                                     stats::quantile(df[[measure_col]], 0.95)))
  
  min_pts <- 10
  
  for (i in seq_len(max_iterations)) {
    for (start in seq_len(nrow(df) - min_pts)) {
      for (end in seq(start + min_pts, nrow(df))) {
        
        if ((end - start + 1) < min_pts) next
        
        model <- tryCatch(
          lm(log(df[[measure_col]][start:end]) ~
               df[[time_col]][start:end]),
          error = function(e) NULL)
        
        if (is.null(model)) next
        
        r2 <- summary(model)$r.squared
        if (!is.na(r2) && r2 > best_r2) {
          best_r2    <- r2
          best_model <- model
          best_start <- start
          best_end   <- end
        }
      }
    }
    break        # en permisiva basta la 1.ª iteración
  }
  
  list(start = best_start, end = best_end, model = best_model)
}

# 3. Calcular parámetros – ROBUSTO
calculate_growth_rates_robust <- function(df) {
  
  df %>%
    dplyr::group_by(Well) %>%
    dplyr::do({
      
      phase <- identify_exponential_phase_robust(.,
                                                 time_col = "Time",
                                                 measure_col = "Measurements")
      
      model <- phase$model
      start <- phase$start
      end   <- phase$end
      
      if (!is.null(model)) {
        
        lag_time <- .$Time[which.max(.$Time[1:start])]
        
        dplyr::tibble(
          µMax            = coef(model)[2],
          max_percap_time = mean(.$Time[start:end]),
          doub_time       = log(2) / coef(model)[2],
          lag_time        = lag_time,
          ODmax           = max(.$Measurements),
          max_time        = .$Time[which.max(.$Measurements)],
          AUC             = gcplyr::auc(x = .$Time, y = .$Measurements)
        )
      } else {
        dplyr::tibble(
          µMax            = NA_real_,
          max_percap_time = NA_real_,
          doub_time       = NA_real_,
          lag_time        = NA_real_,
          ODmax           = max(.$Measurements),
          max_time        = NA_real_,
          AUC             = NA_real_
        )
      }
    })
}

# 4. Calcular parámetros – PERMISIVO
calculate_growth_rates_permissive <- function(df) {
  
  df %>%
    dplyr::group_by(Well) %>%
    dplyr::do({
      
      phase <- identify_exponential_phase_permissive(.,
                                                     time_col = "Time",
                                                     measure_col = "Measurements")
      
      model <- phase$model
      start <- phase$start
      end   <- phase$end
      
      if (!is.null(model)) {
        
        lag_time <- .$Time[which.max(.$Time[1:start])]
        
        dplyr::tibble(
          Well           = .$Well[1],
          µMax            = coef(model)[2],
          max_percap_time = mean(.$Time[start:end]),
          doub_time       = log(2) / coef(model)[2],
          lag_time        = lag_time,
          ODmax           = max(.$Measurements),
          max_time        = .$Time[which.max(.$Measurements)],
          AUC             = gcplyr::auc(x = .$Time, y = .$Measurements)
        )
      } else {
        dplyr::tibble(
          Well           = .$Well[1],
          µMax            = NA_real_,
          max_percap_time = NA_real_,
          doub_time       = NA_real_,
          lag_time        = NA_real_,
          ODmax           = max(.$Measurements),
          max_time        = NA_real_,
          AUC             = NA_real_
        )
      }
    })
}

# 5. Detectar valores vacíos
is_empty_value <- function(x) {
  is.na(x) | x == "" | is.nan(x)
}
# ────────────────────────────────────────────────────────────────

#───────────────────────────────────────────────────────────────────────────────
# Helper: asegura que existan PlotSettings y columnas de parámetros
#───────────────────────────────────────────────────────────────────────────────
prepare_platemap <- function(df_datos, cfg) {
  
  # ─ 1. PlotSettings inexistente o vacío ────────────────────────────────────
  if (is.null(cfg) || nrow(cfg) == 0 || !"Parameter" %in% names(cfg)) {
    message("⚠️  PlotSettings no encontrado: se genera configuración mínima")
    # Identificamos columnas numéricas >> posibles parámetros
    param_cols <- setdiff(names(df_datos),
                          c("Strain","Media","Orden",
                            "BiologicalReplicate","TechnicalReplicate","Well"))
    if (length(param_cols) == 0) {
      param_cols <- "Parametro_dummy"
      df_datos[[param_cols]] <- NA_real_
    }
    cfg <- tibble::tibble(
      Parameter = param_cols,
      Y_Max     = 1,
      Interval  = 1,
      Y_Title   = param_cols
    )
  }
  
  # ─ 2. Asegurar que todas las columnas de cfg$Parameter existan en df_datos ─
  faltantes <- setdiff(cfg$Parameter, names(df_datos))
  if (length(faltantes)) {
    df_datos[ faltantes ] <- NA_real_
  }
  
  list(datos = df_datos, cfg = cfg)
}



