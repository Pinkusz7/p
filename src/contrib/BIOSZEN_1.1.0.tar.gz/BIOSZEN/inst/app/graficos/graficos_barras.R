# Helpers para gráficos de barras ---------------------------------------------

get_palette <- function(n) {
  switch(input$colorMode,
         "Default"        = safe_hue(n),
         "Blanco y Negro" = rep("black", n),
         "Viridis"        = viridis::viridis(n),
         "Plasma"         = viridis::plasma(n),
         "Magma"          = viridis::magma(n),
         "Cividis"        = viridis::cividis(n),
         "Set1"           = RColorBrewer::brewer.pal(n = n, name = "Set1"),
         "Set2"           = RColorBrewer::brewer.pal(n = n, name = "Set2"),
         "Set3"           = RColorBrewer::brewer.pal(n = n, name = "Set3"),
         "Dark2"          = RColorBrewer::brewer.pal(n = n, name = "Dark2"),
         "Accent"         = RColorBrewer::brewer.pal(n = n, name = "Accent"),
         "Paired"         = RColorBrewer::brewer.pal(n = n, name = "Paired"),
         "Pastel1"        = RColorBrewer::brewer.pal(n = n, name = "Pastel1"),
         "Pastel2"        = RColorBrewer::brewer.pal(n = n, name = "Pastel2"),
         safe_hue(n))
}

plot_barras <- function(scope, strain = NULL) {
  build_plot(scope, strain, "Barras")
}
