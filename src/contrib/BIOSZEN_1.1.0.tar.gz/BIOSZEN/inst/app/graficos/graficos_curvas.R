# Helpers para gráficos de curvas ---------------------------------------------

plot_curvas <- function(scope, strain = NULL) {
  build_plot(scope, strain, "Curvas")
}
