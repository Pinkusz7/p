# Helpers from the original app -------------------------------------------------

# Generic helpers to convert matrices to tidy tibbles
matrix_to_tibble <- function(mat, colname = "p.adj") {
  tibble::as_tibble(mat, rownames = "grupo1") |>
    tidyr::pivot_longer(-grupo1,
                        names_to  = "grupo2",
                        values_to = colname) |>
    dplyr::filter(!is.na(.data[[colname]]))
}

# Helper: convierte matriz de p-values de PMCMRplus a tibble
pmcmr_to_tibble <- function(obj) {
  mat <- obj$p.value
  tibble::as_tibble(mat, rownames = "grupo1") |>
    tidyr::pivot_longer(-grupo1,
                        names_to  = "grupo2",
                        values_to = "p.adj") |>
    dplyr::filter(!is.na(p.adj))
}

# Estadística -----------------------------------------------------------
split_comparison <- function(x) {
  stringr::str_split_fixed(x, "-", 2)
}

dunnett_to_tibble <- function(obj) {
  mat <- obj[[1]][ , 4, drop = FALSE]
  cmp <- split_comparison(rownames(mat))
  tibble(
    grupo1 = cmp[, 1],
    grupo2 = cmp[, 2],
    p.adj  = mat[, 1]
  )
}

set_control <- function(df, control_lbl) {
  if (!is.null(control_lbl) && control_lbl %in% df$Label)
    df$Label <- forcats::fct_relevel(df$Label, control_lbl)
  df
}

safe_pairwise_t <- function(df, method = "sidak") {
  res <- rstatix::pairwise_t_test(df, Valor ~ Label, p.adjust.method = method)
  if (nrow(res) == 0) tibble() else res
}

# Utilidades para nombres de archivos ---------------------------------
safe_file <- function(x) {
  ext  <- tools::file_ext(x)
  name <- tools::file_path_sans_ext(x)
  name <- gsub("[^A-Za-z0-9_\\-]", "_", name)
  paste0(name, ".", ext)
}

safe_sheet <- function(x) {
  gsub("[^A-Za-z0-9_]", "_", x)
}

sanitize <- function(x) {
  gsub("[/\\\\:*?\"<>|]", "_", x)
}

# Paleta segura -------------------------------------------------------
# Devuelve un vector de colores usando hue_pal() o un vector vacío si n es 0.
safe_hue <- function(n) {
  if (n > 0) scales::hue_pal()(n) else character(0)
}
