# BIOSZEN MANUAL

## 1. Download Templates
- **Reference platemap-parameters file (download)**: example metadata and settings
- **Reference curves file (download)**: example for curve mode

## 2. App Interface
1. **Load metadata-parameters (.xlsx)**
2. **Load Curves (.xlsx)** (optional)
3. **Instructions (download)**: this manual as PDF
4. **Scope**: "Strain-specific" or "Combined"
5. **Strain**: dropdown shown when scope is "Strain-specific"
6. **Chart Type**: Boxplot, Bar, Curves, Stacked or Correlation
7. **Normalize to a control**: enable normalization and choose the reference media
8. **Filters**: choose media, groups and replicates
9. **Axis and style settings**: scale, titles, font, line width plus **label angle** and **multi-row layout**
10. **Parameter and title**
11. **Downloads**: PNG image, data, metadata, statistical results and **PDF manual**

### Statistical Analysis Panel
- **Normality**: Shapiro-Wilk, Kolmogorov-Smirnov and Anderson-Darling
- **Significance**: ANOVA, Kruskal-Wallis, t test, Wilcoxon, etc.
- **Significance bars**: configurable width, spacing and label size

### Growth Rates Panel
Load curve files to compute parameters such as µMax, lag time and AUC.

## 3. Chart-specific settings
### Boxplot and Bar
- Customize **point size** and **point distribution**
- Control **error bars** and **group order**

### Curves
- Configure axis limits, intervals and titles

### Stacked
- Select parameters to stack and their order

### Correlation
- Choose axes, method and display the regression line

## 4. Manual download
The manual is stored as Markdown (`MANUAL_EN.md`). When downloaded from the app it is automatically converted to PDF preserving the bold headings and sections.
