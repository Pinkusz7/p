# MANUAL BIOSZEN

## 1. Descarga de plantillas
- **Archivo de referencia platemap-parametros (descargar)**: ejemplo de metadata y configuración.
- **Archivo de referencia de curvas (descargar)**: ejemplo para el modo de curvas.

## 2. Interfaz de la app
1. **Cargar metadata-parametros (.xlsx)**
2. **Cargar Curvas (.xlsx)** (opcional)
3. **Instrucciones (descargar)**: este manual en PDF
4. **Ámbito**: "Por Cepa" o "Combinado"
5. **Cepa**: desplegable disponible cuando el ámbito es "Por Cepa"
6. **Gráfico**: Boxplot, Barras, Curvas, Apiladas o Correlación
7. **Normalizar por un control**: activa la normalización y selecciona el medio de referencia
8. **Filtros**: selecciona medios, grupos y réplicas
9. **Ajustes de eje y estilo**: escala, títulos, fuente, grosor de líneas y ahora **ángulo de etiquetas** y **disposición en varias filas**
10. **Parámetro a graficar y título**
11. **Descargas**: imagen PNG, datos, metadata, resultados estadísticos y **manual en PDF**

### Panel de análisis estadístico
- **Normalidad**: Shapiro-Wilk, Kolmogorov-Smirnov y Anderson-Darling
- **Significancia**: ANOVA, Kruskal-Wallis, t test, Wilcoxon, etc.
- **Barras de significancia**: configurables con grosor, separación y tamaño

### Panel de Growth Rates
Carga archivos de curvas y calcula parámetros como µMax, lag time y AUC.

## 3. Ajustes específicos de gráficos
### Boxplot y Barras
- Personaliza **tamaño** y **distribución de puntos**
- Control de **barras de error** y **orden de grupos**

### Curvas
- Límite de ejes, intervalos y títulos configurables

### Apiladas
- Selecciona parámetros a agrupar y su orden

### Correlación
- Elegir ejes, método y mostrar línea de regresión

## 4. Descarga del manual
El manual se almacena como archivo Markdown (`MANUAL_ES.md`). Al descargar desde la app se genera automáticamente un PDF manteniendo el formato con títulos en negrita y secciones separadas.
